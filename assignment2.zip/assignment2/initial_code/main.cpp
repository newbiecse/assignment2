/*
 * Created by: Dinh Quang Tuan
 * Created date: May 4 2015
 * Project: assignment 2 - programming fundamental
 * Description: this file includes main entry point for program
 */

#include "dictionary.h"

int main() {
	// dictionary structure
	Dictionary dict;

	// list of actions
	ActionsList actions;

	// stream output file
	ofstream outFile;

	// load dictionary from text file
	load_dictionary(dict);

	// load action from text file
	load_actions(actions);

	// open outpu file for writing
	outFile.open(OUTPUT_FILE);

	// executes all actions
	do_action(dict, actions, outFile);

	// close output file
	outFile.close();

	return 0;
}
