/*
 * Created by: Dinh Quang Tuan
 * Created date: May 4 2015
 * Project: assignment 2 - programming fundamental
 * Description: this file defines basic Dictionary structures and methods interface
 */

#ifndef __DICTIONARY__H__
#define __DICTIONARY__H__
#endif // __DICTIONARY__H__

#define _CRT_SECURE_NO_DEPRECATE
#include <fstream>
#include <string>
#include <sstream>
#include <string.h>
using namespace std;

/*
 *  define basic parameters
 */

// dictionary filename
#define DICT_FILE		"dictionary.txt"
// action filename
#define ACTION_FILE		"action.txt"
// output filename
#define OUTPUT_FILE		"output.txt"

// method errors
#define ERROR_MESSAGE_1_1 	"Insertion error"
#define ERROR_MESSAGE_2_1	"Deletion error"
#define ERROR_MESSAGE_3_1	"Search error"

// maximum size of a dictionary
const int kWords = 100;
// maximum size of a word
const int kMeanings = 10;
// maximum size of a meaning
const int kExamples = 10;
// maximum size of action list
const int kActions = 100;

// maximum length of a tag name
const int kTagChars = 10;
// maximum length of a line
const int kLineChars = 200;
// maximum length of a word definition
const int kWordChars = 2000;

// types of word
typedef enum {
	NOUN, ADJECTIVE, VERB, UNDEFINED
} WordType;

// types of action
typedef enum {
	INSERT, REMOVE, CRYSTAL, SEARCH, EXPORT, INVALID
} ActionType;

/*
 * Dictionary structure
 * A dictionary contains many words
 * A word contains many meanings
 * A meaning contains: its word type, its definition and many examples
 * An examples contains an sentence and its translation
 *
 */

// Example structure
typedef struct {
	// example sentence
	string sentence;
	// translation of sentence
	string translation;
} Instance;

// Meaning structure
typedef struct {
	// the number of examples
	int size;
	// Word type
	WordType type;
	// definition of item
	string definition;
	// list of examples
	Instance examples[kExamples];
} Meaning;

// Word structure
typedef struct {
	// the number of word's meaning
	int size;
	// representation in dictionary
	string item;
	// list of meanings
	Meaning meaning[kMeanings];
} Word;

// Dictionary structure
typedef struct {
	// the number of words
	int size;
	// list of words
	Word words[kWords];
} Dictionary;

/*
 * Action structure
 * An action list contains many action
 * An action contains its identification number and following parameters.
 */

// Action structure
typedef struct {
	// action number
	ActionType type;
	// action parameters
	string value;
} Action;

// action list structure
typedef struct {
	// the number of actions
	int size;
	// list of actions
	Action list[kActions];
} ActionsList;

/*
 * Dictionary methods interface
 */

/*
 * Returns the WordType value from its name
 *
 * @param type String name of type
 * @return integer value of the name
 */
WordType get_word_type(string type);

/*
 * loads dictionary into structure from Dictionary file
 *
 * @param reference dict: The dictionary structure
 * @return word type
 */
void load_dictionary(Dictionary &dict);

/*
 * loads action into structure from text file
 *
 * @param reference actions: The Action list structure
 */
void load_actions(ActionsList &actions);

/*
 * Exports dictionary to a text file
 *
 * @param outFile: The stream output file
 * @param dict: The dictionary structure
 */
void export_dictionary(ofstream &outFile, Dictionary &dict);

/*
 * Writes a word structure on a text file
 *
 * @param outFile: The steam output file
 * @param word: The word structure
 */
void write_word(ofstream &outFile, Word word);

/*
 * Writes an error on a text file
 *
 * @param outFile: The steam output file
 * @param error: defined error
 */
void write_error(ofstream &outFile, string error);

/*
 * Executes all actions in action list
 *
 * @param reference dict: The dictionary structure
 * @param actions: list of actions
 * @param outFile: The steam output file
 */
void do_action(Dictionary &dict, ActionsList actions, ofstream &outFile);

/*
 * Inserts a word to dictionary
 *
 * @param reference dict: The dictionary structure
 * @param new_word: The word structure
 * @return true if success, otherwise return false
 */
bool insert(Dictionary &dict, Word new_word);

/*
 * Removes a word from dictionry based on its name
 *
 * @param reference dict: The dictionary structure
 * @param name: the name of word
 * @return true if success, otherwise return false
 */
bool remove(Dictionary &dict, string name);

/*
 * Removes all words which satisfies crystal condition
 *
 * @param reference dict: The dictionary structure
 * @return true if success, otherwise return false
 */
bool remove_by_crystal(Dictionary &dict);

/*
 * Searches a word in dictionary based on its name
 *
 * @param reference dict: The dictionary structure
 * @param name: the name of word
 * @param reference word: updating word by target if searching gets success
 * @return true if success, otherwise return false
 */
bool search(Dictionary &dict, string name, Word &word);
