/*
 * Created by: Dinh Quang Tuan
 * Created date: May 4 2015
 * Project: assignment 2 - programming fundamental
 * Description: this file implements for Dictionary methods defined in dictionary.h
 */

#ifndef __DICTIONARY__CPP__
#define __DICTIONARY__CPP__
#endif //__DICTIONARY__CPP__

#include "dictionary.h"

/*
 * Returns the WordType value from its name
 *
 * @param name: string name of type
 * @return word type value of the name
 */
WordType get_word_type(string name) {
	WordType type = UNDEFINED;
	if (name.compare("noun") == 0) {
		type = NOUN;
	} else if (name.compare("adjective") == 0) {
		type = ADJECTIVE;
	} else if (name.compare("verb") == 0) {
		type = VERB;
	} else {
		type = UNDEFINED;
	}

	return type;
}

/*
 * Returns the name of a word type
 *
 * @param type: integer value of type
 * @return the name of type
 */
string get_type(WordType type) {
	string name = "";
	switch (type) {
	case NOUN: {
		name = "noun";
		break;
	}
	case ADJECTIVE: {
		name = "adjective";
		break;
	}
	case VERB: {
		name = "verb";
		break;
	}
	default: {
		name = "";
	}
	}
	return name;
}

/*
 * Returns the ActionType value from its code
 *
 * @param ftype : floating point value of action code
 * @return ACTION TYPE value of respective action
 */
ActionType get_action(float ftype) {
	ActionType action = INVALID;
	std::ostringstream ss;
	ss << ftype;
	string x(ss.str());

	if (x.compare("1.1") == 0)
		action = INSERT;
	else if (x.compare("2.1") == 0)
		action = REMOVE;
	else if (x.compare("2.2") == 0)
		action = CRYSTAL;
	else if (x.compare("3.1") == 0)
		action = SEARCH;
	else if (x.compare("4.1") == 0)
		action = EXPORT;
	else
		action = INVALID;

	return action;
}

/*
 * Loads action into structure from text file
 *
 * @param reference actions: The Action list structure
 */
void load_actions(ActionsList &actions) {
	// open text file
	FILE* fp = fopen(ACTION_FILE, "r");
	// check if it is empty
	if (fp == NULL) {
		actions.size = 0;
		return;
	}
	string str; // following parameter
	char loc[kLineChars];
	char value[kWordChars];
	int r = 0; // scan response value
	int size = -1; // size of action list
	float ftype = 0.0; // action code
	float temp = 0.0;
	do {
		// extract action code
		r = fscanf(fp, "%f\n", &temp);
		if (r != 0) {
			str.assign(value);
			if (size > -1) {
				// assign action
				actions.list[size].type = get_action(ftype);
				actions.list[size].value = str;
			}
			if (r != EOF) {
				size++;
				ftype = temp;
				strcpy(value, "");
			} else {
				actions.size = size + 1;
			}
		} else {
			// extract parameters
			r = fscanf(fp, "%[^\n]\n", loc);
			if (r != 0 && r != EOF) {
				strcat(value, loc);
				strcat(value, "\n");
			}
		}
	} while (r != EOF);
	fclose(fp);
}

/*
 * Exports dictionary to a text file
 *
 * @param outFile: The stream output file
 * @param dict: The dictionary structure
 */
void export_dictionary(ofstream &outFile, Dictionary &dict) {
	for (int i = 0; i < dict.size; ++i) {
		// write item
		outFile << "<item> \"" << dict.words[i].item << '"';
		for (int j = 0; j < dict.words[i].size; ++j) {
			// write word
			Meaning mean = dict.words[i].meaning[j];
			outFile << endl << "<" << get_type(mean.type) << ">" << " \""
					<< mean.definition << "\" ";
			for (int k = 0; k < mean.size; ++k) {
				// write meaning
				outFile << '"' << mean.examples[k].sentence << "\" \""
						<< mean.examples[k].translation << "\" ";
			}
		}
		//		if (i + 1 < dict.size)
		outFile << endl;
	}
}

/*
 * Writes a word structure on a text file
 *
 * @param outFile: The steam output file
 * @param word: The word structure
 */
void write_word(ofstream &outFile, Word word) {
	// write word item
	outFile << "<item> \"" << word.item << '"';
	for (int j = 0; j < word.size; ++j) {
		// write word
		Meaning mean = word.meaning[j];
		outFile << endl << "<" << get_type(mean.type) << ">" << " \""
				<< mean.definition << "\" ";
		for (int k = 0; k < mean.size; ++k) {
			// write meaning
			outFile << '"' << mean.examples[k].sentence << "\" \""
					<< mean.examples[k].translation << "\" ";
		}
	}
	outFile << endl;
}

/*
 * Writes an error on a text file
 *
 * @param outFile: The steam output file
 * @param error: defined error
 */
void write_error(ofstream &outFile, string error) {
	outFile << error << endl;
}
